const complaintsList = document.getElementById("complaintsList");
db.collection("complaints")
  .orderBy("timestamp", "desc")
  .get()
  .then(snapshot => {
    if (snapshot.empty) {
      complaintsList.innerHTML = "<p>No complaints submitted yet.</p>";
      return;
    }

    snapshot.forEach(doc => {
      const data = doc.data();

      const card = document.createElement("div");
      card.className = "complaint-card";

      card.innerHTML = `
        <h3>${data.title}</h3>
        <p><strong>Description:</strong> ${data.description}</p>
        <p><strong>Category:</strong> ${data.category}</p>
        ${data.imageUrl ? `<img src="${data.imageUrl}" width="250">` : ""}
        <p><strong>Status:</strong> ${data.status}</p>
        <hr>
      `;

      complaintsList.appendChild(card);
    });
  })
  .catch(error => {
    console.error("Error fetching complaints:", error);
    complaintsList.innerHTML = "<p>⚠️ Failed to load complaints.</p>";
  });
