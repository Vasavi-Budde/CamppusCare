document.getElementById("lostFoundForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const type = document.getElementById("type").value;
  const itemName = document.getElementById("itemName").value;
  const description = document.getElementById("description").value;
  const imageFile = document.getElementById("image").files[0];
  const personName = document.getElementById("personName").value;
  const contact = document.getElementById("contact").value;
  const statusMsg = document.getElementById("statusMsg");

  try {
    let imageUrl = "";

    if (imageFile) {
      const storageRef = storage.ref("lostfound-images/" + Date.now() + "_" + imageFile.name);
      await storageRef.put(imageFile);
      imageUrl = await storageRef.getDownloadURL();
    }

    await db.collection("lostfound").add({
      type,
      itemName,
      description,
      imageUrl,
      personName,
      contact,
      timestamp: new Date()
    });

    statusMsg.innerText = "✅ Submitted successfully!";
    document.getElementById("lostFoundForm").reset();
  } catch (error) {
    console.error("Error submitting:", error);
    statusMsg.innerText = "❌ Something went wrong.";
  }
});
