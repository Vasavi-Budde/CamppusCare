const itemsList = document.getElementById("itemsList");
db.collection("lostfound")
  .orderBy("timestamp", "desc")
  .get()
  .then(snapshot => {
    if (snapshot.empty) {
      itemsList.innerHTML = "<p>No lost/found items yet.</p>";
      return;
    }

    snapshot.forEach(doc => {
      const data = doc.data();

      const card = document.createElement("div");
      card.className = "lostfound-card";

      card.innerHTML = `
        <h3>${data.itemName} (${data.type})</h3>
        <p><strong>Description:</strong> ${data.description}</p>
        ${data.imageUrl ? `<img src="${data.imageUrl}" width="250">` : ""}
        <p><strong>Reported by:</strong> ${data.personName}</p>
        <p><strong>Contact:</strong> ${data.contact}</p>
        <hr>
      `;

      itemsList.appendChild(card);
    });
  })
  .catch(error => {
    console.error("Error fetching lost/found items:", error);
    itemsList.innerHTML = "<p>⚠️ Error loading items.</p>";
  });
