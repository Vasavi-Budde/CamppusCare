import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyA5voT8I24va01kvkEvVO6MhwD6-QDbz0g",
  authDomain: "campuscare-9f3b8.firebaseapp.com",
  projectId: "campuscare-9f3b8",
  storageBucket: "campuscare-9f3b8.appspot.com",
  messagingSenderId: "130935944097",
  appId: "1:130935944097:web:d661041e8a033ca7f811e0",
  measurementId: "G-LYTGWTE4P1"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

export { db, storage };
