import { db, storage } from './firebase-config.js';
document.getElementById("complaintForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;
  const category = document.getElementById("category").value;
  const imageFile = document.getElementById("image").files[0];
  const statusMsg = document.getElementById("statusMsg");

  try {
    let imageUrl = "";

    if (imageFile) {
      const storageRef = storage.ref("complaint-images/" + Date.now() + "_" + imageFile.name);
      await storageRef.put(imageFile);
      imageUrl = await storageRef.getDownloadURL();
    }

    await db.collection("complaints").add({
      title: title,
      description: description,
      category: category,
      imageUrl: imageUrl,
      status: "Pending",
      timestamp: new Date()
    });

    statusMsg.innerText = "✅ Complaint submitted successfully!";
    document.getElementById("complaintForm").reset();

  } catch (error) {
    console.error("Error adding complaint:", error);
    statusMsg.innerText = "❌ Failed to submit complaint.";
  }
});
